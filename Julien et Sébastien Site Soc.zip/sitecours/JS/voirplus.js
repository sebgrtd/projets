const popupbox = document.querySelector('.popup-screen');
const popupTitle = document.querySelector('.popup-box h3');
const popupContent = document.querySelector('.popup-box p');
const popupExit = document.querySelector('.popup-box i');


const elTitle = document.querySelectorAll('.card h3');
const elContents = document.querySelectorAll('.card p');
const voirplus = document.querySelectorAll('.card button');

const navBar = document.querySelector('nav');

popupExit.addEventListener('click', () => {
    popupbox.classList.remove("active");
    navBar.style = "opacity:1;"
});

popupbox.addEventListener('click', e => {
    if(e.currentTarget !== e.target){
        return;
    }
    else{
        popupbox.classList.remove("active");
        navBar.style = "opacity:1;"
    }
});

for(let i = 0; i < voirplus.length; i++){
    voirplus[i].addEventListener('click', () => {
        navBar.style = "opacity:0;"
        popupbox.classList.add("active");
        popupTitle.innerHTML = elTitle[i].innerHTML;
        popupContent.innerHTML = elContents[i].innerHTML;
    });
    
}

