const texte1 = document.querySelector("section div h1")
const texte2 = document.querySelector("section div p")
const image = document.querySelector("section img")


window.addEventListener('load', () => {
    image.style = "opacity:1; transform:translateX(0)"
    setTimeout(() => {
        texte1.style = 'opacity: 1; transform:translateX(0)';
        setTimeout(() => { texte2.style = 'opacity: 1; transform:translateX(0)' },1400)
    }, 1200)
    
})