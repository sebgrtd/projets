const sections = document.querySelectorAll("section");
const navLi = document.querySelectorAll("nav ul li");
window.addEventListener("scroll", () => {
  let current = "";
  sections.forEach((section,index) => {
    const sectionTop = section.offsetTop;
    const sectionHeight = section.clientHeight;
    if (pageYOffset >= sectionTop - sectionHeight / 3) {
      currenti = index;
    }
  });

  for(let i = 0; i < navLi.length; i++)
  {
      if (i == currenti){
        navLi[currenti].classList.add("active");
      }
      else{
        navLi[i].classList.remove("active");
      }
  }
  
});


// source https://codepen.io/Web_Cifar/pen/LYRBbVE