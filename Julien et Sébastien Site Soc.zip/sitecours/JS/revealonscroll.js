
window.addEventListener("scroll", () => {
    const toreveal = document.querySelectorAll('.reveal');
    for(let i = 0; i < toreveal.length; i++)
    {
        const windowHeight = window.innerHeight;
        const revealTop = toreveal[i].getBoundingClientRect().top;
        const revealpoint = 550;
        if(revealTop < windowHeight - revealpoint){
            toreveal[i].classList.add('active');
        }
        else{
            toreveal[i].classList.remove('active');
        }
    }
});
